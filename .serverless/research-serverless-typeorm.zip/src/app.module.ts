import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AuthModule } from './auth/auth.module';
import { PostModule } from './post/post.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Admin } from './typeorm/entities/Admin';
import { Post } from './typeorm/entities/Post';
import { Content } from './typeorm/entities/Content';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'research.ccj6jewtx0pp.us-east-2.rds.amazonaws.com',
      port: 3306,
      username: 'jaethem8',
      password: 'printJaehyeok123123',
      database: 'research',
      entities: [Admin, Post, Content],
    }),
    AuthModule,
    PostModule,
  ],
})
export class AppModule {}
