export class ContentDTO {
  order: number;
  writing: string | null;
  tag: string | null;
  link: string | null;
  image: string | null;
  code: string | null;
  important: string | null;
}
